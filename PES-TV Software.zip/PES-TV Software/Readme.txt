The results represented in all tables are obtained using following MATLAB files:

PES-TV:
BM3D_All_SaltPepper_EpsilonCont_PESC.m

BM3D:
BM3D_All_SaltPepper_EpsilonCont_BM3D.m

Median-BM3D:
BM3D_All_SaltPepper_EpsilonCont_MED.m