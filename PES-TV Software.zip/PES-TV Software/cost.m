function [cost] = cost(y0, x, ny)

cost = tv(x, ny);

end

